# Gamatek — Landing Page (static, untuk Vercel)

Landing page `gamatek.co.id` yang dikonversi dari backup WordPress + Elementor
(`gamatek.co.id_s_567_20260330152038.tar.gz`) menjadi situs statis murni.
Tidak butuh PHP, database, atau build step.

```
public/                     ← root situs yang di-serve Vercel
  index.html                ← halaman Home (header + konten + footer)
  assets/
    css/                    ← CSS hasil generate Elementor (post-2, -12, -23, -53)
    elementor/              ← aset frontend Elementor 3.34.0 (CSS, JS, Swiper, animasi)
    elementor-pro/          ← aset Pro Elements 3.34.0 (animated headline, nested carousel, sticky)
    hello-elementor/        ← CSS/JS tema Hello Elementor 3.4.5
    js/wp/                  ← jQuery & util WordPress yang dipakai Elementor
    fonts/                  ← Figtree & Sora (Google Fonts, di-host lokal)
    media/                  ← gambar, logo, favicon
  favicon.ico
  robots.txt, sitemap.xml
  google0b8f83a65ba429b9.html  ← file verifikasi Google Search Console (sebelumnya dari Site Kit)
vercel.json                 ← konfigurasi Vercel (output dir, redirect, header)
```

## Deploy ke Vercel

**Lewat dashboard (paling mudah)**
1. Push folder ini ke repo GitHub/GitLab.
2. Di Vercel: *Add New → Project → Import* repo tersebut.
3. Framework Preset: **Other**. Build/Install command dibiarkan kosong —
   `vercel.json` sudah mengarahkan output ke folder `public/`.
4. Deploy.

**Lewat CLI**
```bash
npx vercel --prod
```

**Domain**: di *Project → Settings → Domains*, tambahkan `gamatek.co.id`.
- Jadikan **`gamatek.co.id` (tanpa www) sebagai domain utama**. Kalau Vercel menawarkan
  menambah `www.gamatek.co.id`, pilih opsi *redirect `www.gamatek.co.id` → `gamatek.co.id`*,
  **jangan** pilih rekomendasi default Vercel (apex → www). Canonical, `og:url`, `sitemap.xml`,
  `robots.txt`, dan file verifikasi Google semuanya memakai `https://gamatek.co.id/`.
- DNS domain ini ada di Cloudflare dan juga berisi record email (MX Google Workspace) serta
  TXT verifikasi. **Cukup ubah record `A` untuk `@`** (dan tambah `CNAME www` bila perlu) sesuai
  nilai yang ditampilkan Vercel, dengan proxy Cloudflare dimatikan (DNS only / awan abu-abu).
  Jangan pindahkan nameserver ke Vercel, supaya email tidak terganggu.

## Yang dipertahankan dari situs lama
- Tampilan identik dengan render Elementor asli (diverifikasi per-elemen di 1440/1024/768/390 px).
- Animasi masuk, animated headline, carousel proyek & logo klien, header sticky,
  video latar YouTube, anchor `#works`, `#services`, `#contact`, `#client`.
- Google Analytics (Google tag `GT-TQVK6SM2` → GA4 `G-K3SE51QBF4`) yang sebelumnya dipasang Site Kit.
  Tag hanya aktif di `gamatek.co.id`/`www.gamatek.co.id`, jadi kunjungan ke URL preview
  `*.vercel.app` atau localhost tidak ikut tercatat.
- Meta description, canonical `https://gamatek.co.id/`, favicon.

## Yang ditambahkan / dihapus
- Ditambah: Open Graph/Twitter card (pakai `open-graph.webp` yang sudah ada), `robots.txt`, `sitemap.xml`
  (URL lama `/wp-sitemap.xml` dan `/sample-page` di-redirect lewat `vercel.json`).
- Dihapus: semua bagian dinamis WordPress (RSS, oEmbed, REST API, emoji script, wp-admin, plugin keamanan/cache).

## Mengubah konten
Teks, link, dan nomor kontak ada langsung di `public/index.html`
(cari teks yang ingin diubah, mis. `hi@gamatek.co.id` atau `wa.me/628112131550`).
Gambar ada di `public/assets/media/`.
